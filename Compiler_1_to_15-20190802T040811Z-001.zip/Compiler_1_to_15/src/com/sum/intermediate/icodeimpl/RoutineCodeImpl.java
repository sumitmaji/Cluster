package com.sum.intermediate.icodeimpl;

import com.sum.intermediate.RoutineCode;

public enum RoutineCodeImpl implements RoutineCode {

	READ, READLN, WRITE, WRITELN, ABS, ARCTAN, CHR, COS, EOF, EOLN, 
	EXP, LN, ODD, PRED, ROUND, SIN, SQR, SQRT, SUCC, TRUNC, ORD, DECLARED, FORWARD
}
