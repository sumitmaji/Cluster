package com.sum.intermediate.typeimpl;

import java.util.HashMap;

import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeForm;
import com.sum.intermediate.TypeKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.Predefined;

;
/**
 * <h1>TypeSpecImpl</h1>
 * 
 * <p>
 * A Pascal type specification implementation.
 * </p>
 */
public class TypeSpecImpl extends HashMap<TypeKey, Object> implements TypeSpec {
	private TypeForm form; // type form
	private SymTabEntry identifier; // type identifier

	/**
	 * Constructor.
	 * 
	 * @param form
	 *            the type form.
	 */
	public TypeSpecImpl(TypeForm form) {
		this.form = form;
		this.identifier = null;
	}

	/**
	 * Constructor.
	 * 
	 * @param value
	 *            a string value.
	 */
	public TypeSpecImpl(String value) {
		this.form = TypeFormImpl.ARRAY;
		TypeSpec indexType = new TypeSpecImpl(TypeFormImpl.SUBRANGE);
		indexType.setAttribute(TypeKeyImpl.SUBRANGE_BASE_TYPE,
				Predefined.integerType);
		indexType.setAttribute(TypeKeyImpl.SUBRANGE_MIN_VALUE, 1);
		indexType.setAttribute(TypeKeyImpl.SUBRANGE_MAX_VALUE, value.length());
		setAttribute(TypeKeyImpl.ARRAY_INDEX_TYPE, indexType);
		setAttribute(TypeKeyImpl.ARRAY_ELEMENT_TYPE, Predefined.charType);
		setAttribute(TypeKeyImpl.ARRAY_ELEMENT_COUNT, value.length());
	}

	/**
	 * Set an attribute of the specification.
	 * 
	 * @param key
	 *            the attribute key.
	 * @param value
	 *            the attribute value.
	 */
	public void setAttribute(TypeKey key, Object value) {
		this.put(key, value);
	}

	/**
	 * Get the value of an attribute of the specification.
	 * 
	 * @param key
	 *            the attribute key.
	 * @return the attribute value.
	 */
	public Object getAttribute(TypeKey key) {
		return this.get(key);
	}

	/**
	 * @return true if this is a Pascal string type.
	 */
	public boolean isPascalString() {
		if (form == TypeFormImpl.ARRAY) {
			TypeSpec elmtType = (TypeSpec) getAttribute(TypeKeyImpl.ARRAY_ELEMENT_TYPE);
			TypeSpec indexType = (TypeSpec) getAttribute(TypeKeyImpl.ARRAY_INDEX_TYPE);
			return (elmtType.baseType() == Predefined.charType)
					&& (indexType.baseType() == Predefined.integerType);
		} else {
			return false;
		}
	}
	
	/**
	 * @return the base type of this type.
	 */
	public TypeSpec baseType() {
		return (TypeFormImpl) form == TypeFormImpl.SUBRANGE ? (TypeSpec) getAttribute(TypeKeyImpl.SUBRANGE_BASE_TYPE)
				: this;
	}

	@Override
	public TypeForm getForm() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setIdentifier(SymTabEntry identifier) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SymTabEntry getIdentifier() {
		// TODO Auto-generated method stub
		return null;
	}
}