package com.sum.intermediate;

public interface ICodeNodeType {

}
