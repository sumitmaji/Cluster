package com.sum.intermediate;

public interface TypeKey {

}
