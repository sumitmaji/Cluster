package com.sum.intermediate;

public interface ICodeKey {

}
