package com.sum.intermediate;

public interface TypeForm {
}