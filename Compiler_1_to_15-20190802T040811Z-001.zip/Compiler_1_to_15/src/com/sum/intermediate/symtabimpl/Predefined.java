package com.sum.intermediate.symtabimpl;

import java.util.ArrayList;

import com.sum.intermediate.Definition;
import com.sum.intermediate.RoutineCode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.SymTabStack;
import com.sum.intermediate.TypeFactory;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.RoutineCodeImpl;
import com.sum.intermediate.typeimpl.TypeFormImpl;
import com.sum.intermediate.typeimpl.TypeKeyImpl;

/**
 * <h1>Predefined</h1>
 * 
 * <p>
 * Enter the predefined Pascal types, identifiers, and constants into the symbol
 * table.
 * </p>
 */
public class Predefined {
	// Predefined types.
	public static TypeSpec integerType;
	public static TypeSpec realType;
	public static TypeSpec booleanType;
	public static TypeSpec charType;
	public static TypeSpec undefinedType;
	// Predefined identifiers.
	public static SymTabEntry integerId;
	public static SymTabEntry realId;
	public static SymTabEntry booleanId;
	public static SymTabEntry charId;
	public static SymTabEntry falseId;
	public static SymTabEntry trueId;

	public static SymTabEntry readId;
	public static SymTabEntry readlnId;
	public static SymTabEntry writeId;
	public static SymTabEntry writelnId;
	public static SymTabEntry absId;
	public static SymTabEntry arctanId;
	public static SymTabEntry chrId;
	public static SymTabEntry cosId;
	public static SymTabEntry eofId;
	public static SymTabEntry eolnId;
	public static SymTabEntry expId;
	public static SymTabEntry lnId;
	public static SymTabEntry oddId;
	public static SymTabEntry ordId;
	public static SymTabEntry predId;
	public static SymTabEntry roundId;
	public static SymTabEntry sinId;
	public static SymTabEntry sqrId;
	public static SymTabEntry sqrtId;
	public static SymTabEntry succId;
	public static SymTabEntry truncId;

	/**
	 * Initialize a symbol table stack with predefined identifiers.
	 * 
	 * @param symTab
	 *            the symbol table stack to initialize.
	 */
	public static void initialize(SymTabStack symTabStack) {
		initializeTypes(symTabStack);
		initializeConstants(symTabStack);
		initializeStandardRoutines(symTabStack);
	}

	/**
	 * Initialize the standard procedures and functions.
	 * 
	 * @param symTabStack
	 *            the symbol table stack to initialize.
	 */
	private static void initializeStandardRoutines(SymTabStack symTabStack) {
		readId = enterStandard(symTabStack, DefinitionImpl.PROCEDURE, "read",
				RoutineCodeImpl.READ);
		readlnId = enterStandard(symTabStack, DefinitionImpl.PROCEDURE,
				"readln", RoutineCodeImpl.READLN);
		writeId = enterStandard(symTabStack, DefinitionImpl.PROCEDURE, "write",
				RoutineCodeImpl.WRITE);
		writelnId = enterStandard(symTabStack, DefinitionImpl.PROCEDURE,
				"writeln", RoutineCodeImpl.WRITELN);
		absId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "abs",
				RoutineCodeImpl.ABS);
		arctanId = enterStandard(symTabStack, DefinitionImpl.FUNCTION,
				"arctan", RoutineCodeImpl.ARCTAN);
		chrId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "chr",
				RoutineCodeImpl.CHR);
		cosId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "cos",
				RoutineCodeImpl.COS);
		eofId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "eof",
				RoutineCodeImpl.EOF);
		eolnId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "eoln",
				RoutineCodeImpl.EOLN);
		expId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "exp",
				RoutineCodeImpl.EXP);
		lnId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "ln",
				RoutineCodeImpl.LN);
		oddId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "odd",
				RoutineCodeImpl.ODD);
		ordId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "ord",
				RoutineCodeImpl.ORD);
		predId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "pred",
				RoutineCodeImpl.PRED);
		roundId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "round",
				RoutineCodeImpl.ROUND);
		sinId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "sin",
				RoutineCodeImpl.SIN);
		sqrId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "sqr",
				RoutineCodeImpl.SQR);
		sqrtId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "sqrt",
				RoutineCodeImpl.SQRT);
		succId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "succ",
				RoutineCodeImpl.SUCC);
		truncId = enterStandard(symTabStack, DefinitionImpl.FUNCTION, "trunc",
				RoutineCodeImpl.TRUNC);
	}

	/**
	 * Enter a standard procedure or function into the symbol table stack.
	 * 
	 * @param symTabStack
	 *            the symbol table stack to initialize.
	 * @param defn
	 *            either PROCEDURE or FUNCTION.
	 * @param name
	 *            the procedure or function name.
	 */
	private static SymTabEntry enterStandard(SymTabStack symTabStack,
			Definition defn, String name, RoutineCode routineCode) {
		SymTabEntry procId = symTabStack.enterLocal(name);
		procId.setDefinition(defn);
		procId.setAttribute(SymTabKeyImpl.ROUTINE_CODE, routineCode);
		return procId;
	}

	/**
	 * Initialize the predefined types.
	 * 
	 * @param symTabStack
	 *            the symbol table stack to initialize.
	 */
	private static void initializeTypes(SymTabStack symTabStack) {
		// Type integer.
		integerId = symTabStack.enterLocal("integer");
		integerType = TypeFactory.createType(TypeFormImpl.SCALAR);
		integerType.setIdentifier(integerId);
		integerId.setDefinition(DefinitionImpl.TYPE);
		integerId.setTypeSpec(integerType);
		// Type real.
		realId = symTabStack.enterLocal("real");
		realType = TypeFactory.createType(TypeFormImpl.SCALAR);
		realType.setIdentifier(realId);
		realId.setDefinition(DefinitionImpl.TYPE);
		realId.setTypeSpec(realType);
		// Type boolean.
		booleanId = symTabStack.enterLocal("boolean");
		booleanType = TypeFactory.createType(TypeFormImpl.ENUMERATION);
		booleanType.setIdentifier(booleanId);
		booleanId.setDefinition(DefinitionImpl.TYPE);
		booleanId.setTypeSpec(booleanType);
		// Type char.
		charId = symTabStack.enterLocal("char");
		charType = TypeFactory.createType(TypeFormImpl.SCALAR);
		charType.setIdentifier(charId);
		charId.setDefinition(DefinitionImpl.TYPE);
		charId.setTypeSpec(charType);
		// Undefined type.
		undefinedType = TypeFactory.createType(TypeFormImpl.SCALAR);
	}

	/**
	 * Initialize the predefined constant.
	 * 
	 * @param symTabStack
	 *            the symbol table stack to initialize.
	 */
	private static void initializeConstants(SymTabStack symTabStack) {
		// Boolean enumeration constant false.
		falseId = symTabStack.enterLocal("false");
		falseId.setDefinition(DefinitionImpl.ENUMERATION_CONSTANT);
		falseId.setTypeSpec(booleanType);
		falseId.setAttribute(SymTabKeyImpl.CONSTANT_VALUE, new Integer(0));
		// Boolean enumeration constant true.
		trueId = symTabStack.enterLocal("true");
		trueId.setDefinition(DefinitionImpl.ENUMERATION_CONSTANT);
		trueId.setTypeSpec(booleanType);
		trueId.setAttribute(SymTabKeyImpl.CONSTANT_VALUE, new Integer(1));
		// Add false and true to the boolean enumeration type.
		ArrayList<SymTabEntry> constants = new ArrayList<SymTabEntry>();
		constants.add(falseId);
		constants.add(trueId);
		booleanType.setAttribute(TypeKeyImpl.ENUMERATION_CONSTANTS, constants);
	}
}