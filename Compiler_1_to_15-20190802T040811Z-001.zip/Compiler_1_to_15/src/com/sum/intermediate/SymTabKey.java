package com.sum.intermediate;

public interface SymTabKey {

}
