package com.sum.frontend.pascal;

import com.sum.frontend.Source;
import com.sum.frontend.Token;

public class PascalToken extends Token {

	public PascalToken(Source source) throws Exception {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
