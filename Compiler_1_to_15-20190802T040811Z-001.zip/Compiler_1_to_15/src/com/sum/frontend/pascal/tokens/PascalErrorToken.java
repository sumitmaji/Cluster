package com.sum.frontend.pascal.tokens;

import com.sum.frontend.Source;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalToken;

import static com.sum.frontend.pascal.PascalTokenType.ERROR;
public class PascalErrorToken extends PascalToken{

	public PascalErrorToken(Source source, PascalErrorCode errorCode, String tokenText) throws Exception{
		super(source);
		this.text = tokenText;
		this.type = ERROR;
		this.value = errorCode;
	}
	
	/**
	 * Do nothing. Do not consume any character.
	 */
	protected void extract() throws Exception{
	}
}
