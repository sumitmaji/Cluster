package com.sum.frontend.pascal.tokens;

import com.sum.frontend.Source;
import com.sum.frontend.pascal.PascalToken;
import com.sum.frontend.pascal.PascalTokenType;

import static com.sum.frontend.pascal.PascalTokenType.*;
public class PascalWordToken extends PascalToken {

	public PascalWordToken(Source source) throws Exception {
		super(source);
	}
	
	/**
	 * Extract pascal word token from the source
	 */
	public void extract() throws Exception{
		StringBuilder textBuffer = new StringBuilder();
		char currentChar = currentChar();
		
		//Get the word character(letter or digit). The scanner has already determined
		//that the first character is a letter.
		while(Character.isLetterOrDigit(currentChar)){
			textBuffer.append(currentChar);
			currentChar = nextChar();
		}
		
		text = textBuffer.toString();
		
		//Is it a reserved word or identifier?
		type = (RESERVED_WORDS.contains(text.toLowerCase())) ? 
				PascalTokenType.valueOf(text.toUpperCase()) : //reserved word
					IDENTIFIER; //Identifier
	}

}
