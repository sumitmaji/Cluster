package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.Definition;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;


public class SimpleTypeParser extends TypeSpecificationParser{

	public SimpleTypeParser(PascalParserTD parent) {
		super(parent);
	}

	
	// Synchronization set for starting a simple type specification.
	static final
	EnumSet<PascalTokenType> SIMPLE_TYPE_START_SET =
	ConstantDefinitionsParser.CONSTANT_START_SET.clone();
	static {
	SIMPLE_TYPE_START_SET.add(PascalTokenType.LEFT_PAREN);
	SIMPLE_TYPE_START_SET.add(PascalTokenType.COMMA);
	SIMPLE_TYPE_START_SET.add(PascalTokenType.SEMICOLON);
	}
	/**
	* Parse a simple Pascal type specification.
	* @param token the current token.
	* @return the simple type specification.
	* @throws Exception if an error occurred.
	*/
	public TypeSpec parse(Token token)
	throws Exception
	{
	// Synchronize at the start of a simple type specification.
	token = synchronize(SIMPLE_TYPE_START_SET);
	switch ((PascalTokenType) token.getType()) {
	case IDENTIFIER: {
	String name = token.getText().toLowerCase();
	SymTabEntry id = symTabStack.lookup(name);
	if (id != null) {
	Definition definition = id.getDefinition();
	// It's either a type identifier
	// or the start of a subrange type.
	if (definition == DefinitionImpl.TYPE) {
	id.appendLineNumber(token.getLineNumber());
	token = nextToken(); // consume the identifier
	// Return the type of the referent type.
	return id.getTypeSpec();
	}
	else if ((definition != DefinitionImpl.CONSTANT) &&
	(definition != DefinitionImpl.ENUMERATION_CONSTANT)) {
	errorHandler.flag(token, PascalErrorCode.NOT_TYPE_IDENTIFIER, this);
	token = nextToken(); // consume theidentifier
	return null;
	}
	else {
	SubrangeTypeParser subrangeTypeParser =
	new SubrangeTypeParser(this);
	return subrangeTypeParser.parse(token);
	}
	}
	else {
	errorHandler.flag(token, PascalErrorCode.IDENTIFIER_UNDEFINED, this);
	token = nextToken(); // consume the identifier
	return null;
	}
	}
	case LEFT_PAREN: {
	EnumerationTypeParser enumerationTypeParser =
	new EnumerationTypeParser(this);
	return enumerationTypeParser.parse(token);
	}
	case COMMA:
	case SEMICOLON: {
	errorHandler.flag(token, PascalErrorCode.INVALID_TYPE, this);
	return null;
	}
	default: {
	SubrangeTypeParser subrangeTypeParser =
	new SubrangeTypeParser(this);
	return subrangeTypeParser.parse(token);
	}
	}
	}
}
