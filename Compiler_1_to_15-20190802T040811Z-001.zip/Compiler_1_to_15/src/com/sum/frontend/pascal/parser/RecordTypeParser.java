package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.TypeFactory;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.typeimpl.TypeFormImpl;
import com.sum.intermediate.typeimpl.TypeKeyImpl;

public class RecordTypeParser extends TypeSpecificationParser {

	public RecordTypeParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	// Synchronization set for the END.
	private static final EnumSet<PascalTokenType> END_SET = DeclarationsParser.VAR_START_SET
			.clone();
	static {
		END_SET.add(PascalTokenType.END);
		END_SET.add(PascalTokenType.SEMICOLON);
	}

	/**
	 * Parse a Pascal record type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @return the record type specification.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public TypeSpec parse(Token token) throws Exception {
		TypeSpec recordType = TypeFactory.createType(TypeFormImpl.RECORD);
		token = nextToken(); // consume RECORD
		// Push a symbol table for the RECORD type specification.
		recordType.setAttribute(TypeKeyImpl.RECORD_SYMTAB, symTabStack.push());
		// Parse the field declarations.
		VariableDeclarationsParser variableDeclarationsParser = new VariableDeclarationsParser(
				this);
		variableDeclarationsParser.setDefinition(DefinitionImpl.FIELD);
		variableDeclarationsParser.parse(token);
		// Pop off the record's symbol table.
		symTabStack.pop();
		// Synchronize at the END.
		token = synchronize(END_SET);
		// Look for the END.
		if (token.getType() == PascalTokenType.END) {
			token = nextToken(); // consume END
		} else {
			errorHandler.flag(token, PascalErrorCode.MISSING_END, this);
		}
		return recordType;
	}

}
