package com.sum.frontend.pascal.parser;

import java.util.ArrayList;
import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.Definition;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

public class VariableDeclarationsParser extends DeclarationsParser {

	public VariableDeclarationsParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	private Definition definition; // how to define the identifier
	// Synchronization set for a variable identifier.
	static final EnumSet<PascalTokenType> IDENTIFIER_SET = DeclarationsParser.VAR_START_SET
			.clone();
	static {
		IDENTIFIER_SET.add(PascalTokenType.IDENTIFIER);
		IDENTIFIER_SET.add(PascalTokenType.END);
		IDENTIFIER_SET.add(PascalTokenType.SEMICOLON);
	}
	// Synchronization set for the start of the next definition or declaration.
	static final EnumSet<PascalTokenType> NEXT_START_SET = DeclarationsParser.ROUTINE_START_SET
			.clone();
	static {
		NEXT_START_SET.add(PascalTokenType.IDENTIFIER);
		NEXT_START_SET.add(PascalTokenType.SEMICOLON);
	}

	/**
	 * Parse variable declarations.
	 * 
	 * @param token
	 *            the initial token.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public void parse(Token token) throws Exception {
		token = synchronize(IDENTIFIER_SET);
		// Loop to parse a sequence of variable declarations
		// separated by semicolons.
		while (token.getType() == PascalTokenType.IDENTIFIER) {
			// Parse the identifier sublist and its type specification.
			parseIdentifierSublist(token,IDENTIFIER_FOLLOW_SET, COMMA_SET);
			token = currentToken();
			TokenType tokenType = token.getType();
			// Look for one or more semicolons after a definition.
			if (tokenType == PascalTokenType.SEMICOLON) {
				while (token.getType() == PascalTokenType.SEMICOLON) {
					token = nextToken(); // consume the ;
				}
			}
			// If at the start of the next definition or declaration,
			// then missing a semicolon.
			else if (NEXT_START_SET.contains(tokenType)) {
				errorHandler.flag(token, PascalErrorCode.MISSING_SEMICOLON,
						this);
			}
			token = synchronize(IDENTIFIER_SET);
		}
	}

	// Synchronization set to start a sublist identifier.
	static final EnumSet<PascalTokenType> IDENTIFIER_START_SET = EnumSet.of(
			PascalTokenType.IDENTIFIER, PascalTokenType.COMMA);
	// Synchronization set to follow a sublist identifier.
	private static final EnumSet<PascalTokenType> IDENTIFIER_FOLLOW_SET = EnumSet
			.of(PascalTokenType.COLON, PascalTokenType.SEMICOLON);
	static {
		IDENTIFIER_FOLLOW_SET.addAll(DeclarationsParser.VAR_START_SET);
	}
	// Synchronization set for the , token.
	private static final EnumSet<PascalTokenType> COMMA_SET = EnumSet.of(
			PascalTokenType.COMMA, PascalTokenType.COLON,
			PascalTokenType.IDENTIFIER, PascalTokenType.SEMICOLON);

	/**
	 * Parse a sublist of identifiers and their type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @return the sublist of identifiers in a declaration.
	 * @throws Exception
	 *             if an error occurred.
	 */
	protected ArrayList<SymTabEntry> parseIdentifierSublist(Token token)
			throws Exception {
		ArrayList<SymTabEntry> sublist = new ArrayList<SymTabEntry>();
		do {
			token = synchronize(IDENTIFIER_START_SET);
			SymTabEntry id = parseIdentifier(token);
			if (id != null) {
				sublist.add(id);
			}
			token = synchronize(COMMA_SET);
			TokenType tokenType = token.getType();
			// Look for the comma.
			if (tokenType == PascalTokenType.COMMA) {
				token = nextToken(); // consume the comma
				if (IDENTIFIER_FOLLOW_SET.contains(token.getType())) {
					errorHandler.flag(token,
							PascalErrorCode.MISSING_IDENTIFIER, this);
				}
			} else if (IDENTIFIER_START_SET.contains(tokenType)) {
				errorHandler.flag(token, PascalErrorCode.MISSING_COMMA, this);
			}
		} while (!IDENTIFIER_FOLLOW_SET.contains(token.getType()));
		// Parse the type specification.
		TypeSpec type = parseTypeSpec(token);
		// Assign the type specification to each identifier in the list.
		for (SymTabEntry variableId : sublist) {
			variableId.setTypeSpec(type);
		}
		return sublist;
	}

	/**
	 * Parse an identifier.
	 * 
	 * @param token
	 *            the current token.
	 * @return the symbol table entry of the identifier.
	 * @throws Exception
	 *             if an error occurred.
	 */
	private SymTabEntry parseIdentifier(Token token) throws Exception {
		SymTabEntry id = null;
		if (token.getType() == PascalTokenType.IDENTIFIER) {
			String name = token.getText().toLowerCase();
			id = symTabStack.lookupLocal(name);
			// Enter a new identifier into the symbol table.
			if (id == null) {
				id = symTabStack.enterLocal(name);
				id.setDefinition(definition);
				id.appendLineNumber(token.getLineNumber());
				// Set its slot number in the local variables array.
				int slot = id.getSymTab().nextSlotNumber();
				id.setAttribute(SymTabKeyImpl.SLOT, slot);
			} else {
				errorHandler.flag(token, PascalErrorCode.IDENTIFIER_REDEFINED,
						this);
			}
			token = nextToken(); // consume the identifier token
		} else {
			errorHandler.flag(token, PascalErrorCode.MISSING_IDENTIFIER, this);
		}
		return id;
	}

	// Synchronization set for the : token.
	private static final EnumSet<PascalTokenType> COLON_SET = EnumSet.of(
			PascalTokenType.COLON, PascalTokenType.SEMICOLON);

	/**
	 * Parse the type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @return the type specification.
	 * @throws Exception
	 *             if an error occurs.
	 */
	protected TypeSpec parseTypeSpec(Token token) throws Exception {
		// Synchronize on the : token.
		token = synchronize(COLON_SET);
		if (token.getType() == PascalTokenType.COLON) {
			token = nextToken(); // consume the :
		} else {
			errorHandler.flag(token, PascalErrorCode.MISSING_COLON, this);
		}
		// Parse the type specification.
		TypeSpecificationParser typeSpecificationParser = new TypeSpecificationParser(
				this);
		TypeSpec type = typeSpecificationParser.parse(token);
		return type;
	}

	public void setDefinition(Definition field) {
		this.definition = field;
	}

	/**
	 * Parse a sublist of identifiers and their type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @param followSet
	 *            the synchronization set to follow an identifier.
	 * @return the sublist of identifiers in a declaration.
	 * @throws Exception
	 *             if an error occurred.
	 */
	protected ArrayList<SymTabEntry> parseIdentifierSublist(Token token,
			EnumSet<PascalTokenType> followSet,
			EnumSet<PascalTokenType> commaSet) throws Exception {
		ArrayList<SymTabEntry> sublist = new ArrayList<SymTabEntry>();
		do {
			token = synchronize(IDENTIFIER_START_SET);
			SymTabEntry id = parseIdentifier(token);
			if (id != null) {
				sublist.add(id);
			}
			token = synchronize(commaSet);
			TokenType tokenType = token.getType();
			// Look for the comma.
			if (tokenType == PascalTokenType.COMMA) {
				token = nextToken(); // consume the comma
				if (followSet.contains(token.getType())) {
					errorHandler.flag(token,
							PascalErrorCode.MISSING_IDENTIFIER, this);
				}
			} else if (IDENTIFIER_START_SET.contains(tokenType)) {
				errorHandler.flag(token, PascalErrorCode.MISSING_COMMA, this);
			}
		} while (!followSet.contains(token.getType()));
		if (definition != DefinitionImpl.PROGRAM_PARM) {
			// Parse the type specification.
			TypeSpec type = parseTypeSpec(token);
			// Assign the type specification to each identifier in the list.
			for (SymTabEntry variableId : sublist) {
				variableId.setTypeSpec(type);
			}
		}
		return sublist;
	}

}
