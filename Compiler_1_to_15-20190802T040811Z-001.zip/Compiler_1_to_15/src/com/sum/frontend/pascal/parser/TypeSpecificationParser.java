package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.EofToken;
import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.Definition;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.ICodeNodeType;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeFactory;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.symtabimpl.SymTabImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.NO_OP;
import static com.sum.intermediate.icodeimpl.ICodeKeyImpl.LINE;
import static com.sum.frontend.pascal.PascalTokenType.*;
import static com.sum.frontend.pascal.PascalErrorCode.*;

public class TypeSpecificationParser extends PascalParserTD {

	/**
	 * Constructor.
	 * 
	 * @param parent
	 *            the parent parser.
	 */
	public TypeSpecificationParser(PascalParserTD parent) {
		super(parent);
	}
	
	// Synchronization set for starting a type specification.
	static final EnumSet<PascalTokenType> TYPE_START_SET =
	SimpleTypeParser.SIMPLE_TYPE_START_SET.clone();
	static {
	TYPE_START_SET.add(PascalTokenType.ARRAY);
	TYPE_START_SET.add(PascalTokenType.RECORD);
	TYPE_START_SET.add(SEMICOLON);
	}
	/**
	* Parse a Pascal type specification.
	* @param token the current token.
	* @return the type specification.
	* @throws Exception if an error occurred.
	*/
	public TypeSpec parse(Token token)
	throws Exception
	{
	// Synchronize at the start of a type specification.
	token = synchronize(TYPE_START_SET);
	switch ((PascalTokenType) token.getType()) {
	case ARRAY: {
	ArrayTypeParser arrayTypeParser = new
	ArrayTypeParser(this);
	return arrayTypeParser.parse(token);
	}
	case RECORD: {
	RecordTypeParser recordTypeParser = new
	RecordTypeParser(this);
	return recordTypeParser.parse(token);
	}
	default: {
	SimpleTypeParser simpleTypeParser = new
	SimpleTypeParser(this);
	return simpleTypeParser.parse(token);
	}
	}
	}
}
