package com.sum.frontend.pascal.parser;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.typeimpl.TypeChecker;

import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.*;
import static com.sum.frontend.pascal.PascalTokenType.*;
import static com.sum.frontend.pascal.PascalErrorCode.*;

public class RepeatStatementParser extends StatementParser {

	public RepeatStatementParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Parse a REPEAT statement.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token) throws Exception {
		token = nextToken(); // consume the REPEAT
		// Create the LOOP and TEST nodes.
		ICodeNode loopNode = ICodeFactory.createICodeNode(LOOP);
		ICodeNode testNode = ICodeFactory.createICodeNode(TEST);
		// Parse the statement list terminated by the UNTIL token.
		// The LOOP node is the parent of the statement subtrees.
		StatementParser statementParser = new StatementParser(this);
		statementParser.parseList(token, loopNode, UNTIL, MISSING_UNTIL);
		token = currentToken();
		// Parse the expression.
		// The TEST node adopts the expression subtree as its only child.
		// The LOOP node adopts the TEST node.
		ExpressionParser expressionParser = new ExpressionParser(this);
		ICodeNode exprNode = expressionParser.parse(token);
		testNode.addChild(exprNode);
		
		// Type check: The test expression must be boolean.
		TypeSpec exprType = exprNode != null ? exprNode.getTypeSpec()
				: Predefined.undefinedType;
		if (!TypeChecker.isBoolean(exprType)) {
			errorHandler.flag(token, INCOMPATIBLE_TYPES, this);
		}
		
		loopNode.addChild(testNode);
		return loopNode;
	}

}
