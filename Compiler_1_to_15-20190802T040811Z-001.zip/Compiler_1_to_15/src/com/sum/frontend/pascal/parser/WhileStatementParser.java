package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.typeimpl.TypeChecker;

import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.*;
import static com.sum.frontend.pascal.PascalTokenType.*;
import static com.sum.frontend.pascal.PascalErrorCode.MISSING_DO;

public class WhileStatementParser extends StatementParser {

	public WhileStatementParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	// Synchronization set for DO.
	private static final EnumSet<PascalTokenType> DO_SET = StatementParser.STMT_START_SET
			.clone();
	static {
		DO_SET.add(DO);
		DO_SET.addAll(StatementParser.STMT_FOLLOW_SET);
	}

	/**
	 * Parse a WHILE statement.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token) throws Exception {
		token = nextToken(); // consume the WHILE
		// Create LOOP, TEST, and NOT nodes.
		ICodeNode loopNode = ICodeFactory.createICodeNode(LOOP);
		ICodeNode breakNode = ICodeFactory.createICodeNode(TEST);
		ICodeNode notNode = ICodeFactory.createICodeNode(ICodeNodeTypeImpl.NOT);
		// The LOOP node adopts the TEST node as its first child.
		// The TEST node adopts the NOT node as its only child.
		loopNode.addChild(breakNode);
		breakNode.addChild(notNode);
		// Parse the expression.
		// The NOT node adopts the expression subtree as its only child.
		ExpressionParser expressionParser = new ExpressionParser(this);
		
		ICodeNode exprNode = expressionParser.parse(token);
		notNode.addChild(exprNode);
		// Type check: The test expression must be boolean.
		TypeSpec
		exprType = exprNode != null ? exprNode.getTypeSpec()
		: Predefined.undefinedType;
		if (!TypeChecker.isBoolean(exprType)) {
		errorHandler.flag(token, PascalErrorCode.INCOMPATIBLE_TYPES, this);
		}
		
		
		// Synchronize at the DO.
		token = synchronize(DO_SET);
		if (token.getType() == DO) {
			token = nextToken(); // consume the DO
		} else {
			errorHandler.flag(token, MISSING_DO, this);
		}
		// Parse the statement.
		// The LOOP node adopts the statement subtree as its second child.
		StatementParser statementParser = new StatementParser(this);
		loopNode.addChild(statementParser.parse(token));
		return loopNode;
	}

}
