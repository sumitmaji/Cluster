package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.Definition;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.SymTab;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeForm;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.typeimpl.TypeChecker;
import com.sum.intermediate.typeimpl.TypeFormImpl;
import com.sum.intermediate.typeimpl.TypeKeyImpl;

public class VariableParser extends StatementParser {

	public VariableParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	// Synchronization set to start a subscript or a field.
	private static final EnumSet<PascalTokenType> SUBSCRIPT_FIELD_START_SET = EnumSet
			.of(PascalTokenType.LEFT_BRACKET, PascalTokenType.DOT);

	/**
	 * Parse a variable.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token) throws Exception {
		// Look up the identifier in the symbol table stack.
		String name = token.getText().toLowerCase();
		SymTabEntry variableId = symTabStack.lookup(name);
		// If not found, flag the error and enter the identifier
		// as an undefined identifier with an undefined type.
		if (variableId == null) {
			errorHandler
					.flag(token, PascalErrorCode.IDENTIFIER_UNDEFINED, this);
			variableId = symTabStack.enterLocal(name);
			variableId.setDefinition(DefinitionImpl.UNDEFINED);
			variableId.setTypeSpec(Predefined.undefinedType);
		}
		return parse(token, variableId);
	}

	/**
	 * Parse a variable.
	 * 
	 * @param token
	 *            the initial token.
	 * @param variableId
	 *            the symbol table entry of the variable identifier.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token, SymTabEntry variableId)
			throws Exception {
		// Check how the variable is defined.
		Definition defnCode = variableId.getDefinition();
		if (!((defnCode == DefinitionImpl.VARIABLE)
				|| (defnCode == DefinitionImpl.VALUE_PARM)
				|| (defnCode == DefinitionImpl.VAR_PARM) || (isFunctionTarget && (defnCode == DefinitionImpl.FUNCTION)))) {
			errorHandler.flag(token, PascalErrorCode.INVALID_IDENTIFIER_USAGE,
					this);
		}
		variableId.appendLineNumber(token.getLineNumber());
		ICodeNode variableNode = ICodeFactory
				.createICodeNode(ICodeNodeTypeImpl.VARIABLE);
		variableNode.setAttribute(ICodeKeyImpl.ID, variableId);
		token = nextToken(); // consume the identifier
		TypeSpec variableType = variableId.getTypeSpec();
		if (!isFunctionTarget) {
			// Parse array subscripts or record fields.
			while (SUBSCRIPT_FIELD_START_SET.contains(token.getType())) {
				ICodeNode subFldNode = token.getType() == PascalTokenType.LEFT_BRACKET ? parseSubscripts(variableType)
						: parseField(variableType);
				token = currentToken();
				// Update the variable's type.
				// The variable node adopts the SUBSCRIPTS or FIELD node.
				variableType = subFldNode.getTypeSpec();
				variableNode.addChild(subFldNode);
			}
		}
		variableNode.setTypeSpec(variableType);
		return variableNode;
	}

	// Synchronization set for the ] token.
	private static final EnumSet<PascalTokenType> RIGHT_BRACKET_SET = EnumSet
			.of(PascalTokenType.RIGHT_BRACKET, PascalTokenType.EQUALS,
					PascalTokenType.SEMICOLON);

	/**
	 * Parse a set of comma-separated subscript expressions.
	 * 
	 * @param variableType
	 *            the type of the array variable.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	private ICodeNode parseSubscripts(TypeSpec variableType) throws Exception {
		Token token;
		ExpressionParser expressionParser = new ExpressionParser(this);
		// Create a SUBSCRIPTS node.
		ICodeNode subscriptsNode = ICodeFactory
				.createICodeNode(ICodeNodeTypeImpl.SUBSCRIPTS);
		do {
			token = nextToken(); // consume the [ or , token
			// The current variable is an array.
			if (variableType.getForm() == TypeFormImpl.ARRAY) {
				// Parse the subscript expression.
				ICodeNode exprNode = expressionParser.parse(token);
				TypeSpec exprType = exprNode != null ? exprNode.getTypeSpec()
						: Predefined.undefinedType;
				// The subscript expression type must be assignment
				// compatible with the array index type.
				TypeSpec indexType = (TypeSpec) variableType
						.getAttribute(TypeKeyImpl.ARRAY_INDEX_TYPE);
				if (!TypeChecker.areAssignmentCompatible(indexType, exprType)) {
					errorHandler.flag(token,
							PascalErrorCode.INCOMPATIBLE_TYPES, this);
				}
				// The SUBSCRIPTS node adopts the subscript expression tree.
				subscriptsNode.addChild(exprNode);
				// Update the variable's type.
				variableType = (TypeSpec) variableType
						.getAttribute(TypeKeyImpl.ARRAY_ELEMENT_TYPE);
			}
			// Not an array type, so too many subscripts.
			else {
				errorHandler.flag(token, PascalErrorCode.TOO_MANY_SUBSCRIPTS,
						this);
				expressionParser.parse(token);
			}
			token = currentToken();
		} while (token.getType() == PascalTokenType.COMMA);
		// Synchronize at the ] token.
		token = synchronize(RIGHT_BRACKET_SET);
		if (token.getType() == PascalTokenType.RIGHT_BRACKET) {
			token = nextToken(); // consume the ] token
		} else {
			errorHandler.flag(token, PascalErrorCode.MISSING_RIGHT_BRACKET,
					this);
		}
		subscriptsNode.setTypeSpec(variableType);
		return subscriptsNode;
	}

	/**
	 * Parse a record field.
	 * 
	 * @param variableType
	 *            the type of the record variable.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	private ICodeNode parseField(TypeSpec variableType) throws Exception {
		// Create a FIELD node.
		ICodeNode fieldNode = ICodeFactory
				.createICodeNode(ICodeNodeTypeImpl.FIELD);
		Token token = nextToken(); // consume the . token
		TokenType tokenType = token.getType();
		TypeForm variableForm = variableType.getForm();
		if ((tokenType == PascalTokenType.IDENTIFIER)
				&& (variableForm == TypeFormImpl.RECORD)) {
			SymTab symTab = (SymTab) variableType
					.getAttribute(TypeKeyImpl.RECORD_SYMTAB);
			String fieldName = token.getText().toLowerCase();
			SymTabEntry fieldId = symTab.lookup(fieldName);
			if (fieldId != null) {
				variableType = fieldId.getTypeSpec();
				fieldId.appendLineNumber(token.getLineNumber());
				// Set the field identifier's name.
				fieldNode.setAttribute(ICodeKeyImpl.ID, fieldId);
			} else {
				errorHandler.flag(token, PascalErrorCode.INVALID_FIELD, this);
			}
		} else {
			errorHandler.flag(token, PascalErrorCode.INVALID_FIELD, this);
		}
		token = nextToken(); // consume the field identifier
		fieldNode.setTypeSpec(variableType);
		return fieldNode;
	}

	// Set to true to parse a function name
	// as the target of an assignment.
	private boolean isFunctionTarget = false;

	/**
	 * Parse a function name as the target of an assignment statement.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parseFunctionNameTarget(Token token) throws Exception {
		isFunctionTarget = true;
		return parse(token);
	}
}
