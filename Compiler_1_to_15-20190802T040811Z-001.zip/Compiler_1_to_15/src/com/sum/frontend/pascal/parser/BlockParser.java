package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.EofToken;
import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.ICodeNodeType;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;

import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.NO_OP;
import static com.sum.intermediate.icodeimpl.ICodeKeyImpl.LINE;
import static com.sum.frontend.pascal.PascalTokenType.*;
import static com.sum.frontend.pascal.PascalErrorCode.*;

public class BlockParser extends PascalParserTD {

	/**
	 * Constructor.
	 * 
	 * @param parent
	 *            the parent parser.
	 */
	public BlockParser(PascalParserTD parent) {
		super(parent);
	}

	/**
	 * Parse a block.
	 * 
	 * @param token
	 *            the initial token.
	 * @param routineId
	 *            the symbol table entry of the routine name.
	 * @return the root node of the parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token, SymTabEntry routineId) throws Exception {
		DeclarationsParser declarationsParser = new DeclarationsParser(this);
		StatementParser statementParser = new StatementParser(this);
		// Parse any declarations.
		declarationsParser.parse(token, routineId);
		token = synchronize(StatementParser.STMT_START_SET);
		TokenType tokenType = token.getType();
		ICodeNode rootNode = null;
		// Look for the BEGIN token to parse a compound statement.
		if (tokenType == BEGIN) {
			rootNode = statementParser.parse(token);
		}
		// Missing BEGIN: Attempt to parse anyway if possible.
		else {
			errorHandler.flag(token, MISSING_BEGIN, this);
			if (StatementParser.STMT_START_SET.contains(tokenType)) {
				rootNode = ICodeFactory
						.createICodeNode(ICodeNodeTypeImpl.COMPOUND);
				statementParser.parseList(token, rootNode, END, MISSING_END);
			}
		}
		return rootNode;
	}
}
