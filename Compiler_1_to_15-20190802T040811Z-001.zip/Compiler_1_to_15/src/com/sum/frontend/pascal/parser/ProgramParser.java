package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.SymTabEntry;

public class ProgramParser extends DeclarationsParser {

	public ProgramParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	// Synchronization set to start a program.
	static final EnumSet<PascalTokenType> PROGRAM_START_SET = EnumSet.of(
			PascalTokenType.PROGRAM, PascalTokenType.SEMICOLON);
	static {
		PROGRAM_START_SET.addAll(DeclarationsParser.DECLARATION_START_SET);
	}

	/**
	 * Parse a program.
	 * 
	 * @param token
	 *            the initial token.
	 * @param parentId
	 *            the symbol table entry of the parent routine's name.
	 * @return null
	 * @throws Exception
	 *             if an error occurred.
	 */
	public SymTabEntry parse(Token token, SymTabEntry parentId)
			throws Exception {
		token = synchronize(PROGRAM_START_SET);
		// Parse the program.
		DeclaredRoutineParser routineParser = new DeclaredRoutineParser(this);
		routineParser.parse(token, parentId);
		// Look for the final period.
		token = currentToken();
		if (token.getType() != PascalTokenType.DOT) {
			errorHandler.flag(token, PascalErrorCode.MISSING_PERIOD, this);
		}
		return null;
	}

}
