package com.sum.frontend.pascal.parser;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.ICodeNodeType;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;

public class CallDeclaredParser extends CallParser {

	public CallDeclaredParser(PascalParserTD parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Parse a call to a declared procedure or function.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token) throws Exception {
		// Create the CALL node.
		ICodeNode callNode = ICodeFactory
				.createICodeNode(ICodeNodeTypeImpl.CALL);
		SymTabEntry pfId = symTabStack.lookup(token.getText().toLowerCase());
		callNode.setAttribute(ICodeKeyImpl.ID, pfId);
		callNode.setTypeSpec(pfId.getTypeSpec());
		token = nextToken(); // consume procedure or function identifier
		ICodeNode parmsNode = parseActualParameters(token, pfId, true, false,
				false);
		callNode.addChild(parmsNode);
		return callNode;
	}

}
