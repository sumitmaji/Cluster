package com.sum.frontend.pascal.parser;

import com.sum.frontend.Token;
import com.sum.frontend.pascal.PascalParserTD;
import com.sum.intermediate.ICodeFactory;
import com.sum.intermediate.ICodeNode;
import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.*;
import static com.sum.frontend.pascal.PascalTokenType.*;
import static com.sum.frontend.pascal.PascalErrorCode.*;

public class CompoundStatementParser extends StatementParser {

	public CompoundStatementParser(PascalParserTD parent) {
		super(parent);
	}

	/**
	 * Parse a compound statement.
	 * 
	 * @param token
	 *            the initial token.
	 * @return the root node of the generated parse tree.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public ICodeNode parse(Token token) throws Exception {
		token = nextToken(); // consume the BEGIN
		// Create the COMPOUND node.
		ICodeNode compoundNode = ICodeFactory.createICodeNode(COMPOUND);
		// Parse the statement list terminated by the END token.
		StatementParser statementParser = new StatementParser(this);
		statementParser.parseList(token, compoundNode, END, MISSING_END);
		return compoundNode;
	}
}
