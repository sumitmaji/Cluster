package com.sum.frontend.pascal.parser;

import java.util.EnumSet;

import com.sum.frontend.Token;
import com.sum.frontend.TokenType;
import com.sum.frontend.pascal.PascalErrorCode;
import com.sum.frontend.pascal.PascalTokenType;
import com.sum.intermediate.Definition;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeFactory;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.typeimpl.TypeFormImpl;
import com.sum.intermediate.typeimpl.TypeKeyImpl;

public class SubrangeTypeParser extends TypeSpecificationParser {

	public SubrangeTypeParser(TypeSpecificationParser parent) {
		super(parent);
	}

	/**
	 * Parse a Pascal subrange type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @return the subrange type specification.
	 * @throws Exception
	 *             if an error occurred.
	 */
	public TypeSpec parse(Token token) throws Exception {
		TypeSpec subrangeType = TypeFactory.createType(TypeFormImpl.SUBRANGE);
		Object minValue = null;
		Object maxValue = null;
		// Parse the minimum constant.
		Token constantToken = token;
		ConstantDefinitionsParser constantParser = new ConstantDefinitionsParser(
				this);
		minValue = constantParser.parseConstant(token);
		// Set the minimum constant's type.
		TypeSpec minType = constantToken.getType() == PascalTokenType.IDENTIFIER ? constantParser
				.getConstantType(constantToken) : constantParser
				.getConstantType(minValue);
		minValue = checkValueType(constantToken, minValue, minType);
		token = currentToken();
		Boolean sawDotDot = false;
		// Look for the .. token.
		if (token.getType() == PascalTokenType.DOT_DOT) {
			token = nextToken(); // consume the .. token
			sawDotDot = true;
		}
		TokenType tokenType = token.getType();
		// At the start of the maximum constant?
		if (ConstantDefinitionsParser.CONSTANT_START_SET.contains(tokenType)) {
			if (!sawDotDot) {
				errorHandler.flag(token, PascalErrorCode.MISSING_DOT_DOT, this);
			}
			// Parse the maximum constant.
			token = synchronize(ConstantDefinitionsParser.CONSTANT_START_SET);
			constantToken = token;
			maxValue = constantParser.parseConstant(token);
			// Set the maximum constant's type.
			TypeSpec maxType = constantToken.getType() == PascalTokenType.IDENTIFIER ? constantParser
					.getConstantType(constantToken) : constantParser
					.getConstantType(maxValue);
			maxValue = checkValueType(constantToken, maxValue, maxType);
			// Are the min and max value types valid?
			if ((minType == null) || (maxType == null)) {
				errorHandler.flag(constantToken,
						PascalErrorCode.INCOMPATIBLE_TYPES, this);
			}
			// Are the min and max value types the same?
			else if (minType != maxType) {
				errorHandler.flag(constantToken,
						PascalErrorCode.INVALID_SUBRANGE_TYPE, this);
			}
			// Min value > max value?
			else if ((minValue != null) && (maxValue != null)
					&& ((Integer) minValue >= (Integer) maxValue)) {
				errorHandler.flag(constantToken, PascalErrorCode.MIN_GT_MAX,
						this);
			}
		} else {
			errorHandler.flag(constantToken,
					PascalErrorCode.INVALID_SUBRANGE_TYPE, this);
		}
		subrangeType.setAttribute(TypeKeyImpl.SUBRANGE_BASE_TYPE, minType);
		subrangeType.setAttribute(TypeKeyImpl.SUBRANGE_MIN_VALUE, minValue);
		subrangeType.setAttribute(TypeKeyImpl.SUBRANGE_MAX_VALUE, maxValue);
		return subrangeType;
	}

	/**
	 * Check a value of a type specification.
	 * 
	 * @param token
	 *            the current token.
	 * @param value
	 *            the value.
	 * @param type
	 *            the type specifiction.
	 * @return the value.
	 */
	private Object checkValueType(Token token, Object value, TypeSpec type) {
		if (type == null) {
			return value;
		}
		if (type == Predefined.integerType) {
			return value;
		} else if (type == Predefined.charType) {
			char ch = ((String) value).charAt(0);
			return Character.getNumericValue(ch);
		} else if (type.getForm() == TypeFormImpl.ENUMERATION) {
			return value;
		} else {
			errorHandler.flag(token, PascalErrorCode.INVALID_SUBRANGE_TYPE,
					this);
			return value;
		}
	}
}
