package com.sum.frontend;

public interface TokenType {

}
