package com.sum.backend.interpreter.executors;

import java.util.ArrayList;
import java.util.List;

import com.sum.backend.Executor;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.message.Message;
import static com.sum.message.MessageType.*;
import static com.sum.intermediate.icodeimpl.ICodeKeyImpl.*;
import static com.sum.intermediate.symtabimpl.SymTabKeyImpl.*;

public class LoopExecutor extends StatementExecutor {

	public LoopExecutor(Executor parent) {
		super(parent);
	}

	/**
	 * Execute an assignment statement.
	 * 
	 * @param node
	 *            the root node of the statement.
	 * @return null.
	 */
	public Object execute(ICodeNode node) {
		boolean exitLoop = false;
		ICodeNode exprNode = null;
		List<ICodeNode> loopChildren = node.getChildren();
		ExpressionExecutor expressionExecutor = new ExpressionExecutor(this);
		StatementExecutor statementExecutor = new StatementExecutor(this);
		// Loop until the TEST expression value is true.
		while (!exitLoop) {
			++executionCount; // count the loop statement itself
			// Execute the children of the LOOP node.
			for (ICodeNode child : loopChildren) {
				ICodeNodeTypeImpl childType = (ICodeNodeTypeImpl) child
						.getType();
				// TEST node?
				if (childType == ICodeNodeTypeImpl.TEST) {
					if (exprNode == null) {
						exprNode = child.getChildren().get(0);
					}
					exitLoop = (Boolean) expressionExecutor.execute(exprNode);
				}
				// Statement node.
				else {
					statementExecutor.execute(child);
				}
				// Exit if the TEST expression value is true,
				if (exitLoop) {
					break;
				}
			}
		}
		return null;
	}

	/**
	 * Send a message about the assignment operation.
	 * 
	 * @param node
	 *            the ASSIGN node.
	 * @param variableName
	 *            the name of the target variable.
	 * @param value
	 *            the value of the expression.
	 */
	private void sendMessage(ICodeNode node, String variableName, Object value) {
		Object lineNumber = node.getAttribute(LINE);
		// Send an ASSIGN message.
		if (lineNumber != null) {
			sendMessage(new Message(ASSIGN, new Object[] { lineNumber,
					variableName, value }));
		}
	}
}
