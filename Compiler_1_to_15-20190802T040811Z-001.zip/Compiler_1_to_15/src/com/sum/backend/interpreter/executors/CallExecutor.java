package com.sum.backend.interpreter.executors;

import com.sum.backend.Executor;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.RoutineCode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.RoutineCodeImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

public class CallExecutor extends StatementExecutor {

	public CallExecutor(Executor parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Execute procedure or function call statement.
	 * 
	 * @param node
	 *            the root node of the call.
	 * @return null.
	 */
	public Object execute(ICodeNode node) {
		SymTabEntry routineId = (SymTabEntry) node.getAttribute(ICodeKeyImpl.ID);
		RoutineCode routineCode = (RoutineCode) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_CODE);
		CallExecutor callExecutor = routineCode == RoutineCodeImpl.DECLARED ? new CallDeclaredExecutor(
				this) : new CallStandardExecutor(this);
		++executionCount; // count the call statement
		return callExecutor.execute(node);
	}

}
