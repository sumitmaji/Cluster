package com.sum.backend.interpreter.executors;

import java.util.ArrayList;

import com.sum.backend.Executor;
import com.sum.backend.interpreter.ActivationRecord;
import com.sum.backend.interpreter.Cell;
import com.sum.backend.interpreter.MemoryFactory;
import com.sum.intermediate.Definition;
import com.sum.intermediate.ICode;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

public class CallDeclaredExecutor extends CallExecutor {

	public CallDeclaredExecutor(Executor parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Execute a call to a declared procedure or function.
	 * 
	 * @param node
	 *            the CALL node.
	 * @return null.
	 */
	public Object execute(ICodeNode node) {
		SymTabEntry routineId = (SymTabEntry) node
				.getAttribute(ICodeKeyImpl.ID);
		ActivationRecord newAr = MemoryFactory
				.createActivationRecord(routineId);
		// Execute any actual parameters and initialize
		// the formal parameters in the new activation record.
		if (node.getChildren().size() > 0) {
			ICodeNode parmsNode = node.getChildren().get(0);
			ArrayList<ICodeNode> actualNodes = parmsNode.getChildren();
			ArrayList<SymTabEntry> formalIds = (ArrayList<SymTabEntry>) routineId
					.getAttribute(SymTabKeyImpl.ROUTINE_PARMS);
			executeActualParms(actualNodes, formalIds, newAr);
		}
		// Push the new activation record.
		runtimeStack.push(newAr);
		sendCallMessage(node, routineId.getName());
		// Get the root node of the routine's intermediate code.
		ICode iCode = (ICode) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_ICODE);
		ICodeNode rootNode = iCode.getRoot();
		// Execute the routine.
		StatementExecutor statementExecutor = new StatementExecutor(this);
		Object value = statementExecutor.execute(rootNode);
		// Pop off the activation record.
		runtimeStack.pop();
		sendReturnMessage(node, routineId.getName());
		return value;
	}

	/**
	 * Execute the actual parameters of a call.
	 * 
	 * @param actualNodes
	 *            the list of nodes of the actual parms.
	 * @param formalIds
	 *            the list of symbol table entries of the formal parms.
	 * @param newAr
	 *            the new activation record.
	 */
	private void executeActualParms(ArrayList<ICodeNode> actualNodes,
			ArrayList<SymTabEntry> formalIds, ActivationRecord newAr) {
		ExpressionExecutor expressionExecutor = new ExpressionExecutor(this);
		AssignmentExecutor assignmentExecutor = new AssignmentExecutor(this);
		for (int i = 0; i < formalIds.size(); ++i) {
			SymTabEntry formalId = formalIds.get(i);
			Definition formalDefn = formalId.getDefinition();
			Cell formalCell = newAr.getCell(formalId.getName());
			ICodeNode actualNode = actualNodes.get(i);
			// Value parameter.
			if (formalDefn == DefinitionImpl.VALUE_PARM) {
				TypeSpec formalType = formalId.getTypeSpec();
				TypeSpec valueType = actualNode.getTypeSpec().baseType();
				Object value = expressionExecutor.execute(actualNode);
				assignmentExecutor.assignValue(actualNode, formalId,
						formalCell, formalType, value, valueType);
			}
			// VAR parameter.
			else {
				Cell actualCell = (Cell) expressionExecutor
						.executeVariable(actualNode);
				formalCell.setValue(actualCell);
			}
		}
	}

}
