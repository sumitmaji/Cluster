package com.sum.backend.interpreter.executors;

import static com.sum.intermediate.icodeimpl.ICodeKeyImpl.LINE;
import static com.sum.message.MessageType.ASSIGN;

import java.util.List;

import com.sum.backend.Executor;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.message.Message;

public class IfExecutor extends StatementExecutor {

	public IfExecutor(Executor parent) {
		super(parent);
	}

	/**
	 * Execute an assignment statement.
	 * 
	 * @param node
	 *            the root node of the statement.
	 * @return null.
	 */
	public Object execute(ICodeNode node) {
		// Get the IF node's children.
		List<ICodeNode> children = node.getChildren();
		ICodeNode exprNode = children.get(0);
		ICodeNode thenStmtNode = children.get(1);
		ICodeNode elseStmtNode = children.size() > 2 ? children.get(2) : null;
		ExpressionExecutor expressionExecutor = new ExpressionExecutor(this);
		StatementExecutor statementExecutor = new StatementExecutor(this);
		// Evaluate the expression to determine which statement to execute.
		boolean b = (Boolean) expressionExecutor.execute(exprNode);
		if (b) {
			statementExecutor.execute(thenStmtNode);
		} else if (elseStmtNode != null) {
			statementExecutor.execute(elseStmtNode);
		}
		++executionCount; // count the IF statement itself
		return null;
	}

	/**
	 * Send a message about the assignment operation.
	 * 
	 * @param node
	 *            the ASSIGN node.
	 * @param variableName
	 *            the name of the target variable.
	 * @param value
	 *            the value of the expression.
	 */
	private void sendMessage(ICodeNode node, String variableName, Object value) {
		Object lineNumber = node.getAttribute(LINE);
		// Send an ASSIGN message.
		if (lineNumber != null) {
			sendMessage(new Message(ASSIGN, new Object[] { lineNumber,
					variableName, value }));
		}
	}
}
