package com.sum.backend.interpreter.memoryimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.sum.backend.interpreter.Cell;
import com.sum.backend.interpreter.MemoryFactory;
import com.sum.backend.interpreter.MemoryMap;
import com.sum.intermediate.Definition;
import com.sum.intermediate.SymTab;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeForm;
import com.sum.intermediate.TypeKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.typeimpl.TypeFormImpl;
import com.sum.intermediate.typeimpl.TypeKeyImpl;

/**
 * <h1>MemoryMapImpl</h1>
 * 
 * <p>
 * The interpreter's runtime memory map.
 * </p>
 * 
 */
public class MemoryMapImpl extends HashMap<String, Cell> implements MemoryMap {
	/**
	 * Constructor. Create a memory map and allocate its memory cells based on
	 * the entries in a symbol table.
	 * 
	 * @param symTab
	 *            the symbol table.
	 */
	public MemoryMapImpl(SymTab symTab) {
		ArrayList<SymTabEntry> entries = symTab.sortedEntries();
		// Loop for each entry of the symbol table.
		for (SymTabEntry entry : entries) {
			Definition defn = entry.getDefinition();
			// Not a VAR parameter: Allocate cells for the data type
			// in the hashmap.
			if ((defn == DefinitionImpl.VARIABLE)
					|| (defn == DefinitionImpl.FUNCTION)
					|| (defn == DefinitionImpl.VALUE_PARM)
					|| (defn == DefinitionImpl.FIELD)) {
				String name = entry.getName();
				TypeSpec type = entry.getTypeSpec();
				put(name, MemoryFactory.createCell(allocateCellValue(type)));
			}
			// VAR parameter: Allocate a single cell to hold a reference
			// in the hashmap.
			else if (defn == DefinitionImpl.VAR_PARM) {
				String name = entry.getName();
				put(name, MemoryFactory.createCell(null));
			}
		}
	}

	/**
	 * Return the memory cell with the given name.
	 * 
	 * @param name
	 *            the name.
	 * @return the cell.
	 */
	public Cell getCell(String name) {
		return get(name);
	}

	/**
	 * @return the list of all the names.
	 */
	public ArrayList<String> getAllNames() {
		ArrayList<String> list = new ArrayList<String>();
		Set<String> names = keySet();
		Iterator<String> it = names.iterator();
		while (it.hasNext()) {
			list.add(it.next());
		}
		return list;
	}

	/**
	 * Make an allocation for a value of a given data type for a memory cell.
	 * 
	 * @param type
	 *            the data type.
	 * @return the allocation.
	 */
	private Object allocateCellValue(TypeSpec type) {
		TypeForm form = type.getForm();
		switch ((TypeFormImpl) form) {
		case ARRAY: {
			return allocateArrayCells(type);
		}
		case RECORD: {
			return allocateRecordMap(type);
		}
		default: {
			return null; // uninitialized scalar value
		}
		}
	}

	/**
	 * Allocate the memory cells of an array.
	 * 
	 * @param type
	 *            the array type.
	 * @return the allocation.
	 */
	private Object[] allocateArrayCells(TypeSpec type) {
		int elmtCount = (Integer) type
				.getAttribute(TypeKeyImpl.ARRAY_ELEMENT_COUNT);
		TypeSpec elmtType = (TypeSpec) type
				.getAttribute(TypeKeyImpl.ARRAY_ELEMENT_TYPE);
		Cell allocation[] = new Cell[elmtCount];
		for (int i = 0; i < elmtCount; ++i) {
			allocation[i] = MemoryFactory
					.createCell(allocateCellValue(elmtType));
		}
		return allocation;
	}

	/**
	 * Allocate the memory map for a record.
	 * 
	 * @param type
	 *            the record type.
	 * @return the allocation.
	 */
	private MemoryMap allocateRecordMap(TypeSpec type) {
		SymTab symTab = (SymTab) type.getAttribute(TypeKeyImpl.RECORD_SYMTAB);
		MemoryMap memoryMap = MemoryFactory.createMemoryMap(symTab);
		return memoryMap;
	}
}