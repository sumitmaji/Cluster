package com.sum.backend.compiler.generators;

import com.sum.backend.CodeGenerator;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.RoutineCode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.RoutineCodeImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

public class CallGenerator extends StatementGenerator{

	public CallGenerator(CodeGenerator parent) {
		super(parent);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Generate code to call a procedure or function.
	 * 
	 * @param node
	 *            the root node of the call.
	 */
	public void generate(ICodeNode node) {
		SymTabEntry routineId = (SymTabEntry) node
				.getAttribute(ICodeKeyImpl.ID);
		RoutineCode routineCode = (RoutineCode) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_CODE);
		CallGenerator callGenerator = (CallGenerator) (routineCode == RoutineCodeImpl.DECLARED ? new CallDeclaredGenerator(this) : new CallStandardGenerator(this));
		callGenerator.generate(node);
	}
}
