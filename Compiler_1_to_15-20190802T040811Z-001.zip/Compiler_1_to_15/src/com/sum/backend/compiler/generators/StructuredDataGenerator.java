package com.sum.backend.compiler.generators;

import com.sum.backend.CodeGenerator;
import com.sum.intermediate.SymTabEntry;

public class StructuredDataGenerator extends CodeGenerator {

	public StructuredDataGenerator(
			CodeGenerator parent) {
		super(parent);
	}

	/**
	* Generate code to allocate the structured data of
	a program,
	* procedure, or function.
	* @param routineId the routine's symbol table entry.
	*/
	public void generate(SymTabEntry routineId)
	{
	}
}
