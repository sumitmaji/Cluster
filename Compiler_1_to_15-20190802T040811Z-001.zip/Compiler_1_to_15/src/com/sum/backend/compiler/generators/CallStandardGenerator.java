package com.sum.backend.compiler.generators;

import java.util.ArrayList;

import com.sum.backend.CodeGenerator;
import com.sum.backend.compiler.Instruction;
import com.sum.backend.compiler.Label;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.ICodeNodeType;
import com.sum.intermediate.RoutineCode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.intermediate.icodeimpl.RoutineCodeImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;
import com.sum.intermediate.typeimpl.TypeFormImpl;

public class CallStandardGenerator extends CodeGenerator {

	public CallStandardGenerator(CodeGenerator parent) {
		super(parent);
	}
	
	ExpressionGenerator exprGenerator=null;

	/**
	 * Generate code to call to a standard procedure or function.
	 * 
	 * @param node
	 *            the CALL node.
	 * @return the function value, or null for a procedure call.
	 */
	public void generate(ICodeNode node) {
		SymTabEntry routineId = (SymTabEntry) node
				.getAttribute(ICodeKeyImpl.ID);
		RoutineCode routineCode = (RoutineCode) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_CODE);
		exprGenerator = new ExpressionGenerator(this);
		ICodeNode actualNode = null;
		// Get the actual parameters of the call.
		if (node.getChildren().size() > 0) {
			ICodeNode parmsNode = node.getChildren().get(0);
			actualNode = parmsNode.getChildren().get(0);
		}
		switch ((RoutineCodeImpl) routineCode) {
		case READ:
		case READLN:
			generateReadReadln(node, routineCode);
			break;
		case WRITE:
		case WRITELN:
			generateWriteWriteln(node, routineCode);
			break;
		case EOF:
		case EOLN:
			generateEofEoln(node, routineCode);
			break;
		case ABS:
		case SQR:
			generateAbsSqr(routineCode, actualNode);
			break;
		case ARCTAN:
		case COS:
		case EXP:
		case LN:
		case SIN:
		case SQRT:
			generateArctanCosExpLnSinSqrt(routineCode, actualNode);
			break;
		case PRED:
		case SUCC:
			generatePredSucc(routineCode, actualNode);
			break;
		case CHR:
			generateChr(actualNode);
			break;
		case ODD:
			generateOdd(actualNode);
			break;
		case ORD:
			generateOrd(actualNode);
			break;
		case ROUND:
		case TRUNC:
			generateRoundTrunc(routineCode, actualNode);
			break;
		}
	}

	/**
	 * Generate code for a call to read or readln.
	 * 
	 * @param callNode
	 *            the CALL node.
	 * @param routineCode
	 *            the routine code.
	 */
	private void generateReadReadln(ICodeNode callNode, RoutineCode routineCode) {
		ICodeNode parmsNode = callNode.getChildren().size() > 0 ? callNode
				.getChildren().get(0) : null;
		String programName = symTabStack.getProgramId().getName();
		String standardInName = programName + "/_standardIn";
		if (parmsNode != null) {
			ArrayList<ICodeNode> actuals = parmsNode.getChildren();
			// Loop to process each actual parameter.
			for (ICodeNode actualNode : actuals) {
				SymTabEntry variableId = (SymTabEntry) actualNode
						.getAttribute(ICodeKeyImpl.ID);
				TypeSpec actualType = actualNode.getTypeSpec();
				TypeSpec baseType = actualType.baseType();
				// Generate code to call the appropriate PascalTextIn method.
				emit(Instruction.GETSTATIC, standardInName, "LPascalTextIn;");
				if (baseType == Predefined.integerType) {
					emit(Instruction.INVOKEVIRTUAL,
							"PascalTextIn.readInteger()I");
				} else if (baseType == Predefined.realType) {
					emit(Instruction.INVOKEVIRTUAL, "PascalTextIn.readReal()F");
				} else if (baseType == Predefined.booleanType) {
					emit(Instruction.INVOKEVIRTUAL,
							"PascalTextIn.readBoolean()Z");
				} else if (baseType == Predefined.charType) {
					emit(Instruction.INVOKEVIRTUAL, "PascalTextIn.readChar()C");
				}
				localStack.increase(1);
				// Store the value that was read into the actual parameter.
				emitStoreVariable(variableId);
				localStack.decrease(1);
			}
		}
		// READLN: Skip the rest of the input line.
		if (routineCode == RoutineCodeImpl.READLN) {
			emit(Instruction.GETSTATIC, standardInName, "LPascalTextIn;");
			emit(Instruction.INVOKEVIRTUAL, "PascalTextIn.nextLine()V");
			localStack.use(1);
		}
	}

	/**
	 * Generate code for a call to eof or eoln.
	 * 
	 * @param callNode
	 *            the CALL node.
	 * @param routineCode
	 *            the routine code.
	 */
	private void generateEofEoln(ICodeNode callNode, RoutineCode routineCode) {
		String programName = symTabStack.getProgramId().getName();
		String standardInName = programName + "/_standardIn";
		// Generate code to call the appropriate PascalTextIn method.
		emit(Instruction.GETSTATIC, standardInName, "LPascalTextIn;");
		if (routineCode == RoutineCodeImpl.EOLN) {
			emit(Instruction.INVOKEVIRTUAL, "PascalTextIn.atEoln()Z");
		} else {
			emit(Instruction.INVOKEVIRTUAL, "PascalTextIn.atEof()Z");
		}
		localStack.increase(1);
	}

	/**
	 * Generate code for a call to write or writeln.
	 * 
	 * @param callNode
	 *            the CALL node.
	 * @param routineCode
	 *            the routine code.
	 */
	private void generateWriteWriteln(ICodeNode callNode,
			RoutineCode routineCode) {
		ICodeNode parmsNode = callNode.getChildren().size() > 0 ? callNode
				.getChildren().get(0) : null;
		StringBuilder buffer = new StringBuilder();
		int exprCount = 0;
		buffer.append("\"");
		// There are actual parameters.
		if (parmsNode != null) {
			ArrayList<ICodeNode> actuals = parmsNode.getChildren();
			// Loop to process each WRITE parameter
			// and build the format string.
			for (ICodeNode writeParmNode : actuals) {
				ArrayList<ICodeNode> children = writeParmNode.getChildren();
				ICodeNode exprNode = children.get(0);
				ICodeNodeType nodeType = exprNode.getType();
				// Append string constants directly to the format string.
				if (nodeType == ICodeNodeTypeImpl.STRING_CONSTANT) {
					String str = (String) exprNode
							.getAttribute(ICodeKeyImpl.VALUE);
					buffer.append(str.replaceAll("%", "%%"));
				}
				// Create and append the appropriate format specification.
				else {
					TypeSpec dataType = exprNode.getTypeSpec().baseType();
					String typeCode = dataType.isPascalString() ? "s"
							: dataType == Predefined.integerType ? "d"
									: dataType == Predefined.realType ? "f"
											: dataType == Predefined.booleanType ? "s"
													: dataType == Predefined.charType ? "c"
															: "s";
					++exprCount; // count the non-constant string parameters
					buffer.append("%");
					// Process any field width and precision values.
					if (children.size() > 1) {
						int w = (Integer) children.get(1).getAttribute(
								ICodeKeyImpl.VALUE);
						buffer.append(w == 0 ? 1 : w);
					}
					if (children.size() > 2) {
						int p = (Integer) children.get(2).getAttribute(
								ICodeKeyImpl.VALUE);
						buffer.append(".");
						buffer.append(p == 0 ? 1 : p);
					}
					buffer.append(typeCode);
				}
			}
			buffer.append(routineCode == RoutineCodeImpl.WRITELN ? "\\n\""
					: "\"");
		}
		emit(Instruction.GETSTATIC, "java/lang/System/out",
				"Ljava/io/PrintStream;");
		localStack.increase(1);
		// WRITELN with no parameters.
		if (parmsNode == null) {
			emit(Instruction.INVOKEVIRTUAL, "java/io/PrintStream.println()V");
			localStack.decrease(1);
		}
		// WRITE or WRITELN with parameters.
		else {
			ArrayList<ICodeNode> actuals = parmsNode.getChildren();
			// Load the format string.
			emit(Instruction.LDC, buffer.toString());
			localStack.increase(1);
			// Generate code to create the values array for String.format().
			if (exprCount > 0) {
				emitLoadConstant(exprCount);
				emit(Instruction.ANEWARRAY, "java/lang/Object");
				localStack.use(3, 1);
				int index = 0;
				ExpressionGenerator exprGenerator = new ExpressionGenerator(
						this);
				// Loop to generate code to evaluate each actua parameter.
				for (ICodeNode writeParmNode : actuals) {
					ArrayList<ICodeNode> children = writeParmNode.getChildren();
					ICodeNode exprNode = children.get(0);
					ICodeNodeType nodeType = exprNode.getType();
					TypeSpec dataType = exprNode.getTypeSpec().baseType();
					// Skip string constants, which were made part of
					// the format string.
					if (nodeType != ICodeNodeTypeImpl.STRING_CONSTANT) {
						emit(Instruction.DUP);
						emitLoadConstant(index++);
						localStack.increase(2);
						exprGenerator.generate(exprNode);
						String signature = dataType.getForm() == TypeFormImpl.SCALAR ? valueOfSignature(dataType)
								: null;
						// Boolean: Write "true" or "false".
						if (dataType == Predefined.booleanType) {
							Label trueLabel = Label.newLabel();
							Label nextLabel = Label.newLabel();
							emit(Instruction.IFNE, trueLabel);
							emit(Instruction.LDC, "\"false\"");
							emit(Instruction.GOTO, nextLabel);
							emitLabel(trueLabel);
							emit(Instruction.LDC, "\"true\"");
							emitLabel(nextLabel);
							localStack.use(1);
						}
						// Convert a scalar value to an object.
						if (signature != null) {
							emit(Instruction.INVOKESTATIC, signature);
						}
						// Store the value into the values vector.
						emit(Instruction.AASTORE);
						localStack.decrease(3);
					}
				}
				// Format the string.
				emit(Instruction.INVOKESTATIC,
						"java/lang/String/format(Ljava/lang/String;"
								+ "[Ljava/lang/Object;)Ljava/lang/String;");
				localStack.decrease(2);
			}
			// Print.
			emit(Instruction.INVOKEVIRTUAL,
					"java/io/PrintStream.print(Ljava/lang/String;)V");
			localStack.decrease(2);
		}
	}

	/**
	 * Generate code for a call to abs or sqr.
	 * 
	 * @param routineCode
	 *            the routine code.
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateAbsSqr(RoutineCode routineCode, ICodeNode actualNode) {
		exprGenerator.generate(actualNode);
		// ABS: Generate code to call the appropriate integer or float
		// java.lang.Math method.
		// SQR: Multiply the value by itself.
		if (actualNode.getTypeSpec() == Predefined.integerType) {
			if (routineCode == RoutineCodeImpl.ABS) {
				emit(Instruction.INVOKESTATIC, "java/lang/Math/abs(I)I");
			} else {
				emit(Instruction.DUP);
				emit(Instruction.IMUL);
				localStack.use(1);
			}
		} else {
			if (routineCode == RoutineCodeImpl.ABS) {
				emit(Instruction.INVOKESTATIC, "java/lang/Math/abs(F)F");
			} else {
				emit(Instruction.DUP);
				emit(Instruction.FMUL);
				localStack.use(1);
			}
		}
	}

	/**
	 * Generate code for a call to arctan, cos, exp, ln, sin, or sqrt.
	 * 
	 * @param routineCode
	 *            the routine code.
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateArctanCosExpLnSinSqrt(RoutineCode routineCode,
			ICodeNode actualNode) {
		String function = null;
		exprGenerator.generate(actualNode);
		// Convert an integer or real value to double.
		TypeSpec actualType = actualNode.getTypeSpec();
		if (actualType == Predefined.integerType) {
			emit(Instruction.I2D);
		} else {
			emit(Instruction.F2D);
		}
		// Select the appropriate java.lang.Math method.
		switch ((RoutineCodeImpl) routineCode) {
		case ARCTAN:
			function = "atan";
			break;
		case COS:
			function = "cos";
			break;
		case EXP:
			function = "exp";
			break;
		case SIN:
			function = "sin";
			break;
		case LN:
			function = "log";
			break;
		case SQRT:
			function = "sqrt";
			break;
		}
		// Call the method and convert the result from double to float.
		emit(Instruction.INVOKESTATIC, "java/lang/Math/" + function + "(D)D");
		emit(Instruction.D2F);
		localStack.use(1);
	}

	/**
	 * Generate code for a call to pred or succ.
	 * 
	 * @param routineCode
	 *            the routine code.
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generatePredSucc(RoutineCode routineCode, ICodeNode actualNode) {
		// Generate code to add or subtract 1 from the value.
		exprGenerator.generate(actualNode);
		emit(Instruction.ICONST_1);
		emit(routineCode == RoutineCodeImpl.PRED ? Instruction.ISUB
				: Instruction.IADD);
		localStack.use(1);
	}

	/**
	 * Generate code for a call to chr.
	 * 
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateChr(ICodeNode actualNode) {
		exprGenerator.generate(actualNode);
		emit(Instruction.I2C);
	}

	/**
	 * Generate code for a call to odd.
	 * 
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateOdd(ICodeNode actualNode) {
		// Generate code to leave the rightmost bit of the value
		// on the operand stack.
		exprGenerator.generate(actualNode);
		emit(Instruction.ICONST_1);
		emit(Instruction.IAND);
		localStack.use(1);
	}

	/**
	 * Generate code for a call to ord.
	 * 
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateOrd(ICodeNode actualNode) {
		// A character value is treated as an integer value.
		if (actualNode.getType() == ICodeNodeTypeImpl.STRING_CONSTANT) {
			int value = ((String) actualNode.getAttribute(ICodeKeyImpl.VALUE))
					.charAt(0);
			emitLoadConstant(value);
			localStack.increase(1);
		} else {
			exprGenerator.generate(actualNode);
		}
	}

	/**
	 * Generate code for a call to round or trunc.
	 * 
	 * @param routineCode
	 *            the routine code.
	 * @param actualNode
	 *            the actual parameter node.
	 */
	private void generateRoundTrunc(RoutineCode routineCode,
			ICodeNode actualNode) {
		exprGenerator.generate(actualNode);
		// ROUND: Generate code to compute floor(value + 0.5).
		if (routineCode == RoutineCodeImpl.ROUND) {
			emitLoadConstant(0.5f);
			emit(Instruction.FADD);
			localStack.use(1);
		}
		// Truncate.
		emit(Instruction.F2I);
	}
}
