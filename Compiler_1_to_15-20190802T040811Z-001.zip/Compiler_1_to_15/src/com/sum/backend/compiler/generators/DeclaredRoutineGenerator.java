package com.sum.backend.compiler.generators;

import java.util.ArrayList;

import com.sum.backend.CodeGenerator;
import com.sum.backend.compiler.Directive;
import com.sum.backend.compiler.Instruction;
import com.sum.backend.compiler.LocalStack;
import com.sum.backend.compiler.LocalVariables;
import com.sum.backend.compiler.PascalCompilerException;
import com.sum.intermediate.Definition;
import com.sum.intermediate.ICode;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.SymTab;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.SymTabKey;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.symtabimpl.DefinitionImpl;
import com.sum.intermediate.symtabimpl.SymTabKeyImpl;

public class DeclaredRoutineGenerator extends CodeGenerator {

	public DeclaredRoutineGenerator(CodeGenerator parent) {
		super(parent);
	}

	private SymTabEntry routineId;
	private String routineName;
	private int functionValueSlot;
	/**
	 * Generate code for a declared procedure or function
	 * 
	 * @param routineId
	 *            the symbol table entry of the routine's name.
	 */
	public void generate(SymTabEntry routineId) throws PascalCompilerException {
		this.routineId = routineId;
		this.routineName = routineId.getName();
		SymTab routineSymTab = (SymTab) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_SYMTAB);
		localVariables = new LocalVariables(routineSymTab.maxSlotNumber());
		localStack = new LocalStack();
		// Reserve an extra variable for the function return value.
		if (routineId.getDefinition() == DefinitionImpl.FUNCTION) {
			functionValueSlot = localVariables.reserve();
			routineId.setAttribute(SymTabKeyImpl.SLOT, functionValueSlot);
		}
		generateRoutineHeader();
		generateRoutineLocals();
		// Generate code to allocate any arrays, records, and strings.
		StructuredDataGenerator structuredDataGenerator = new StructuredDataGenerator(this);
		structuredDataGenerator.generate(routineId);
		generateRoutineCode();
		generateRoutineReturn();
		generateRoutineEpilogue();
	}

	/**
	 * Generate the routine header.
	 */
	private void generateRoutineHeader() {
		String routineName = routineId.getName();
		ArrayList<SymTabEntry> parmIds = (ArrayList<SymTabEntry>) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_PARMS);
		StringBuilder buffer = new StringBuilder();
		// Procedure or function name.
		buffer.append(routineName);
		buffer.append("(");
		// Parameter and return type descriptors.
		if (parmIds != null) {
			for (SymTabEntry parmId : parmIds) {
				buffer.append(typeDescriptor(parmId));
			}
		}
		buffer.append(")");
		buffer.append(typeDescriptor(routineId));
		emitBlankLine();
		emitDirective(Directive.METHOD_PRIVATE_STATIC, buffer.toString());
	}

	/**
	 * Generate directives for the local variables.
	 */
	private void generateRoutineLocals() {
		SymTab symTab = (SymTab) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_SYMTAB);
		ArrayList<SymTabEntry> ids = symTab.sortedEntries();
		emitBlankLine();
		// Loop over all the routine's identifiers and
		// emit a .var directive for each variable and formal parameter.
		for (SymTabEntry id : ids) {
			Definition defn = id.getDefinition();
			if ((defn == DefinitionImpl.VARIABLE)
					|| (defn == DefinitionImpl.VALUE_PARM)
					|| (defn == DefinitionImpl.VAR_PARM)) {
				int slot = (Integer) id.getAttribute(SymTabKeyImpl.SLOT);
				emitDirective(Directive.VAR, slot + " is " + id.getName(),
						typeDescriptor(id));
			}
		}
		// Emit an extra .var directive for an implied functio variable.
		if (routineId.getDefinition() == DefinitionImpl.FUNCTION) {
			emitDirective(Directive.VAR, functionValueSlot + " is "
					+ routineName, typeDescriptor(routineId.getTypeSpec()));
		}
	}

	/**
	 * Generate code for the routine's body.
	 */
	private void generateRoutineCode() throws PascalCompilerException {
		ICode iCode = (ICode) routineId
				.getAttribute(SymTabKeyImpl.ROUTINE_ICODE);
		ICodeNode root = iCode.getRoot();
		emitBlankLine();
		// Generate code for the compound statement.
		StatementGenerator statementGenerator = new StatementGenerator(this);
		statementGenerator.generate(root);
	}

	/**
	 * Generate the routine's return code.
	 */
	private void generateRoutineReturn()
	{
	emitBlankLine();
	// Function: Return the value in the implied function variable.
	if (routineId.getDefinition() == DefinitionImpl.FUNCTION) {
	TypeSpec type = routineId.getTypeSpec();
	emitLoadLocal(type, functionValueSlot);
	emitReturnValue(type);
	localStack.use(1);
	}
	// Procedure: Just return.
	else {
	emit(Instruction.RETURN);
	}
	}

	/**
	 * Generate the routine's epilogue.
	 */
	private void generateRoutineEpilogue() {
		emitBlankLine();
		emitDirective(Directive.LIMIT_LOCALS, localVariables.count());
		emitDirective(Directive.LIMIT_STACK, localStack.capacity());
		emitDirective(Directive.END_METHOD);
	}

}
