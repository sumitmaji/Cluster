package com.sum.backend.compiler.generators;

import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.ADD;
import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.FLOAT_DIVIDE;
import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.INTEGER_DIVIDE;
import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.MULTIPLY;
import static com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl.SUBTRACT;

import java.util.ArrayList;
import java.util.EnumSet;

import com.sum.backend.CodeGenerator;
import com.sum.backend.compiler.Instruction;
import com.sum.backend.compiler.Label;
import com.sum.intermediate.ICodeKey;
import com.sum.intermediate.ICodeNode;
import com.sum.intermediate.SymTabEntry;
import com.sum.intermediate.TypeSpec;
import com.sum.intermediate.icodeimpl.ICodeKeyImpl;
import com.sum.intermediate.icodeimpl.ICodeNodeTypeImpl;
import com.sum.intermediate.symtabimpl.Predefined;
import com.sum.intermediate.typeimpl.TypeChecker;
import com.sum.intermediate.typeimpl.TypeFormImpl;

public class ExpressionGenerator extends StatementGenerator {

	public ExpressionGenerator(CodeGenerator parent) {
		super(parent);
	}
	
	// Set of arithmetic operator node types.
	private static final EnumSet<ICodeNodeTypeImpl> ARITH_OPS = EnumSet.of(ADD,
			SUBTRACT, MULTIPLY, FLOAT_DIVIDE, INTEGER_DIVIDE);


	/**
	 * Generate code to evaluate an expression.
	 * 
	 * @param node
	 *            the root intermediate code node of the compound statement.
	 */
	public void generate(ICodeNode node) {
		ICodeNodeTypeImpl nodeType = (ICodeNodeTypeImpl) node.getType();
		switch (nodeType) {
		case VARIABLE: {
			// Generate code to load a variable's value.
			generateLoadValue(node);
			break;
		}
		case CALL: {
			// Generate code to call a function.
			CallGenerator callGenerator = new
			CallGenerator(this);
			callGenerator.generate(node);
			break;
			}
		case INTEGER_CONSTANT: {
			TypeSpec type = node.getTypeSpec();
			Integer value = (Integer) node.getAttribute(ICodeKeyImpl.VALUE);
			// Generate code to load a boolean constant
			// 0 (false) or 1 (true).
			if (type == Predefined.booleanType) {
				emitLoadConstant(value == 1 ? 1 : 0);
			}
			// Generate code to load an integer constant.
			else {
				emitLoadConstant(value);
			}
			localStack.increase(1);
			break;
		}
		case REAL_CONSTANT: {
			float value = (Float) node.getAttribute(ICodeKeyImpl.VALUE);
			// Generate code to load a float constant.
			emitLoadConstant(value);
			localStack.increase(1);
			break;
		}
		case STRING_CONSTANT: {
			String value = (String) node.getAttribute(ICodeKeyImpl.VALUE);
			// Generate code to load a string constant.
			if (node.getTypeSpec() == Predefined.charType) {
				emitLoadConstant(value.charAt(0));
			} else {
				emitLoadConstant(value);
			}
			localStack.increase(1);
			break;
		}
		case NEGATE: {
			// Get the NEGATE node's expression node child.
			ArrayList<ICodeNode> children = node.getChildren();
			ICodeNode expressionNode = children.get(0);
			// Generate code to evaluate the expression and
			// negate its value.
			generate(expressionNode);
			emit(expressionNode.getTypeSpec() == Predefined.integerType ? Instruction.INEG
					: Instruction.FNEG);
			break;
		}
		case NOT: {
			// Get the NOT node's expression node child.
			ArrayList<ICodeNode> children = node.getChildren();
			ICodeNode expressionNode = children.get(0);
			// Generate code to evaluate the expression and NOT its value.
			generate(expressionNode);
			emit(Instruction.ICONST_1);
			emit(Instruction.IXOR);
			localStack.use(1);
			break;
		}
			// Must be a binary operator.
		default:
			generateBinaryOperator(node, nodeType);
		}
	}

	/**
	 * Generate code to load a variable's value.
	 * 
	 * @param variableNode
	 *            the variable node.
	 */
	protected void generateLoadValue(ICodeNode variableNode) {
		generateLoadVariable(variableNode);
	}

	/**
	 * Generate code to load a variable's address (structured) or value
	 * (scalar).
	 * 
	 * @param variableNode
	 *            the variable node.
	 */
	protected TypeSpec generateLoadVariable(ICodeNode variableNode) {
		SymTabEntry variableId = (SymTabEntry) variableNode.getAttribute(ICodeKeyImpl.ID);
		TypeSpec variableType = variableId.getTypeSpec();
		emitLoadVariable(variableId);
		localStack.increase(1);
		return variableType;
	}

	/**
	 * Generate code to evaluate a binary operator.
	 * 
	 * @param node
	 *            the root node of the expression.
	 * @param nodeType
	 *            the node type.
	 */
	private void generateBinaryOperator(ICodeNode node,
			ICodeNodeTypeImpl nodeType) {
		// Get the two operand children of the operator node.
		ArrayList<ICodeNode> children = node.getChildren();
		ICodeNode operandNode1 = children.get(0);
		ICodeNode operandNode2 = children.get(1);
		TypeSpec type1 = operandNode1.getTypeSpec();
		TypeSpec type2 = operandNode2.getTypeSpec();
		boolean integerMode = TypeChecker.areBothInteger(type1, type2)
				|| (type1.getForm() == TypeFormImpl.ENUMERATION)
				| (type2.getForm() == TypeFormImpl.ENUMERATION);
		boolean realMode = TypeChecker.isAtLeastOneReal(type1, type2)
				|| (nodeType == ICodeNodeTypeImpl.FLOAT_DIVIDE);
		boolean characterMode = TypeChecker.isChar(type1)
				&& TypeChecker.isChar(type2);
		boolean stringMode = type1.isPascalString() && type2.isPascalString();
		if (!stringMode) {
			// Emit code to evaluate the first operand.
			generate(operandNode1);
			if (realMode && TypeChecker.isInteger(type1)) {
				emit(Instruction.I2F);
			}
			// Emit code to evaluate the second operand.
			generate(operandNode2);
			if (realMode && TypeChecker.isInteger(type2)) {
				emit(Instruction.I2F);
			}
		}
		// ====================
		// Arithmetic operators
		// ====================
		if (ARITH_OPS.contains(nodeType)) {
			if (integerMode) {
				// Integer operations.
				switch (nodeType) {
				case ADD:
					emit(Instruction.IADD);
					break;
				case SUBTRACT:
					emit(Instruction.ISUB);
					break;
				case MULTIPLY:
					emit(Instruction.IMUL);
					break;
				case FLOAT_DIVIDE:
					emit(Instruction.FDIV);
					break;
				case INTEGER_DIVIDE:
					emit(Instruction.IDIV);
					break;
				case MOD:
					emit(Instruction.IREM);
					break;
				}
			} else {
				// Float operations.
				switch (nodeType) {
				case ADD:
					emit(Instruction.FADD);
					break;
				case SUBTRACT:
					emit(Instruction.FSUB);
					break;
				case MULTIPLY:
					emit(Instruction.FMUL);
					break;
				case FLOAT_DIVIDE:
					emit(Instruction.FDIV);
					break;
				}
			}
			localStack.decrease(1);
		}
		// ==========
		// AND and OR
		// ==========
		else if (nodeType == ICodeNodeTypeImpl.AND) {
			emit(Instruction.IAND);
			localStack.decrease(1);
		} else if (nodeType == ICodeNodeTypeImpl.OR) {
			emit(Instruction.IOR);
			localStack.decrease(1);
		}
		// ====================
		// Relational operators
		// ====================
		else {
			Label trueLabel = Label.newLabel();
			Label nextLabel = Label.newLabel();
			if (integerMode || characterMode) {
				switch (nodeType) {
				case EQ:
					emit(Instruction.IF_ICMPEQ, trueLabel);
					break;
				case NE:
					emit(Instruction.IF_ICMPNE, trueLabel);
					break;
				case LT:
					emit(Instruction.IF_ICMPLT, trueLabel);
					break;
				case LE:
					emit(Instruction.IF_ICMPLE, trueLabel);
					break;
				case GT:
					emit(Instruction.IF_ICMPGT, trueLabel);
					break;
				case GE:
					emit(Instruction.IF_ICMPGE, trueLabel);
					break;
				}
				localStack.decrease(2);
			} else if (realMode) {
				emit(Instruction.FCMPG);
				switch (nodeType) {
				case EQ:
					emit(Instruction.IFEQ, trueLabel);
					break;
				case NE:
					emit(Instruction.IFNE, trueLabel);
					break;
				case LT:
					emit(Instruction.IFLT, trueLabel);
					break;
				case LE:
					emit(Instruction.IFLE, trueLabel);
					break;
				case GT:
					emit(Instruction.IFGT, trueLabel);
					break;
				case GE:
					emit(Instruction.IFGE, trueLabel);
					break;
				}
				localStack.decrease(2);
			}
			emit(Instruction.ICONST_0); // false
			emit(Instruction.GOTO, nextLabel);
			emitLabel(trueLabel);
			emit(Instruction.ICONST_1); // true
			emitLabel(nextLabel);
			localStack.increase(1);
		}
	}
}
