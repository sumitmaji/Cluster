package com.sum.backend.compiler.generators;

import java.util.ArrayList;

import com.sum.backend.CodeGenerator;
import com.sum.backend.compiler.Instruction;
import com.sum.backend.compiler.PascalCompilerException;
import com.sum.intermediate.ICodeNode;

public class CompoundGenerator extends StatementGenerator {

	public CompoundGenerator(CodeGenerator parent) {
		super(parent);
	}

	/**
	 * Generate code for a compound statement.
	 * 
	 * @param node
	 *            the root node of the compound statement.
	 */
	public void generate(ICodeNode node) throws PascalCompilerException {
		ArrayList<ICodeNode> children = node.getChildren();
		// Loop over the statement children of the COMPOUND node and generate
		// code for each statement. Emit a NOP is there are no statements.
		if (children.size() == 0) {
			emit(Instruction.NOP);
		} else {
			StatementGenerator statementGenerator = new StatementGenerator(this);
			for (ICodeNode child : children) {
				statementGenerator.generate(child);
			}
		}
	}
}
