package com.sum.backend.compiler;

/**
 * <h1>PascalCompilerException</h1>
 * 
 * <p>
 * Error during the Pascal compiler's code generation.
 * </p>
 */
public class PascalRuntimeException extends Exception {
	public PascalRuntimeException(String message) {
		super(message);
	}
}